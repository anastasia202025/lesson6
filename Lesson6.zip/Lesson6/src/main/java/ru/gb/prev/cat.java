package ru.gb.prev;

public class cat extends Animal {
   public cat(){
       super(200,-1);
   }

    @Override
    public void  run (int distance ){
        System.out.printf("Kitty run %s:%s%n",distance,distance<=getMaxRunDistance());
    }

    @Override
    public void swim(int distance) {
        System.out.println("Kitty cannot swim");
    }

}
