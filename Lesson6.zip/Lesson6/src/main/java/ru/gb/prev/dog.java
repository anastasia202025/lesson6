package ru.gb.prev;

public class dog extends Animal{
   public dog(){
       super(500,10);
   }

    @Override
    public void  run (int distance) {
       System.out.printf("Doggy ran %s: %s%n",distance,distance <= getMaxRunDistance());
       }

    @Override
    public void swim(int distance) {
        System.out.printf("Doggy swim %s:%s%n",distance,distance <= getMaxSwimDistance());
    }
}
