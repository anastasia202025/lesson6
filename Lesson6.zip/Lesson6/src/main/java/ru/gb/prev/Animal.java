package ru.gb.prev;

public abstract class Animal {
    private final int maxRunDistance;
    private final int maxSwimDistance;

    protected Animal( int maxRunDistance,int maxSwimDistance){
        this.maxRunDistance=maxRunDistance;
        this.maxSwimDistance=maxSwimDistance;
    }

    public int getMaxRunDistance() {
        return maxRunDistance;
    }

    public int getMaxSwimDistance() {
        return maxSwimDistance;
    }

    public abstract void run(int distance);
    public abstract void swim (int distance);
}
